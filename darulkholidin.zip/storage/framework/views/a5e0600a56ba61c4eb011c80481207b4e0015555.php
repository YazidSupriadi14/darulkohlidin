<?php $__env->startSection('content'); ?>
  
  <!-- Page Heading -->
          <div class="p-3 bg-success text-light">
           <h1 class="display-6 text-center">Info Kelulusan SMA Darul Kholidin </h1>
          </div>
          <!-- Content Row -->
          <div class="row">
          <table class="table m-3">
                            <tbody>
                                <tr>
                                    <td class="bg-success text-white">Nama: </td>
                                    <td><?php echo e($siswa->name); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">NISN: </td>
                                    <td><?php echo e($siswa->nisn); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">NIS: </td>
                                    <td><?php echo e($siswa->nis); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">NO SKL: </td>
                                    <td><?php echo e($siswa->noskl); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Tempat Lahir: </td>
                                    <td><?php echo e($siswa->tmp_lahir); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Tanggal Lahir: </td>
                                    <td><?php echo e($siswa->tgl_lahir); ?></td>
                                </tr>
                                
                                <tr>
                                    <td class="bg-success text-white">Status: </td>
                                    <td><?php echo e($siswa->status); ?></td>
                                </tr>
                            </tbody>
                        </table>

            
          <table class="table m-3">
          <a href="<?php echo e(url('sma/siswa/detail/mapeladd',$siswa->id)); ?>" class="btn btn-primary btn-sm">Tambah Nilai Siswa </a>

                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $siswa->mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center font-weight-bold">Nilai Siswa</td>
                                    <td>
                                    
            
                                    <form action="<?php echo e(url('sma/siswa/detail/mapel/delete',$item->id)); ?>" method="post" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-sm btn-danger"></i>Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Agama: </td>
                                    <td><?php echo e($item->agama); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Pendidikan Kewarganegaraan: </td>
                                    <td><?php echo e($item->pkn); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Bahasa Indonesia: </td>
                                    <td><?php echo e($item->bahasa_indonesia); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Matematika: </td>
                                    <td><?php echo e($item->mtk); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Sejarah: </td>
                                    <td><?php echo e($item->sejarah); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Bahasa Inggris: </td>
                                    <td><?php echo e($item->bahasa_inggris); ?></td>
                                </tr>
                                
                                <tr>
                                    <td class="bg-success text-white">Seni Budaya: </td>
                                    <td><?php echo e($item->seni_budaya); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Pendidikan Jasmani dan Olahraga: </td>
                                    <td><?php echo e($item->pjok); ?></td>
                                </tr>
                                
                                <tr>
                                    <td class="bg-success text-white">PRKW: </td>
                                    <td><?php echo e($item->prkw); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Bahasa Sunda: </td>
                                    <td><?php echo e($item->bahasa_sunda); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Matematika Peminatan: </td>
                                    <td><?php echo e($item->mtk_peminatan); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Biologi: </td>
                                    <td><?php echo e($item->biologi); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Fisika: </td>
                                    <td><?php echo e($item->fisika); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Kimia: </td>
                                    <td><?php echo e($item->kimia); ?></td>
                                </tr>
                                
                                <tr>
                                    <td class="bg-success text-white">Bahasa Arab: </td>
                                    <td><?php echo e($item->bahasa_arab); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Status: </td>
                                    <td><?php echo e($siswa->status); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
            
          </div>
        
         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\darulkholidin\resources\views/pages/admin/sma/detail.blade.php ENDPATH**/ ?>