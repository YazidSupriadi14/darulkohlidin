<?php $__env->startSection('content'); ?>
  
  <!-- Page Heading -->
          <div class=" jumbotron bg-success text-light">
           <h1 class=" text-center">Info Kelulusan SMA Darul Kholidin </h1>
          </div>
          <!-- Content Row -->
          <div class="row">
            <div class="col-md-6">
              <form action="/search" method="get">
                  <input type="text" name="search" class="form-control">
                  <span class="input-group-repend">
                    <button type="submit" class="btn btn-sm btn-primary">Cari Siswa</button>
                  </span>
              </form>
            </div>
          <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama</th>
      <th scope="col">Nisn</th>
      <th scope="col">Status</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php $i = 1 ?>
  <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <th scope="row"><?php echo e($i++); ?></th>
      <td><?php echo e($item->name); ?></td>
      <td><?php echo e($item->nisn); ?></td>
      
      <td class="text-white mt-3 ml-3 font-weight-bold p-1 badge badge-success text-wrap"><?php echo e($item->status); ?></td>
      <td>
      
      <a href="<?php echo e(url('sma/siswa/detail',$item->id)); ?>"  class="btn btn-sm btn-info" title="">View</a>
      <a href="<?php echo e(url('sma/siswa/edit',$item->id)); ?>"  class="btn btn-sm btn-success" title="">Edit</a>

<form action="<?php echo e(url('sma/siswa/delete',$item->id)); ?>" method="post" class="d-inline">
  <?php echo csrf_field(); ?>
  <?php echo method_field('delete'); ?>
  <button class="btn btn-sm btn-danger"></i>Delete</button>
</form>
      </td>
    </tr>
   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td class="text-center" colspan="7">Data Kosong</td>
           </tr> 
    <?php endif; ?>
  </tbody>
</table>
            
          </div>
        
         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\darulkholidin\resources\views/pages/admin/sma/search.blade.php ENDPATH**/ ?>