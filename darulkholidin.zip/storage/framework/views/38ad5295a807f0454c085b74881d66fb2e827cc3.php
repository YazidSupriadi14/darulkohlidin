<?php $__env->startSection('content'); ?>
  
  <!-- Page Heading -->
          <div class="p-3 bg-success text-light">
          <?php if($siswa->status == "lulus"): ?>
           <h1 class="display-6 text-center">Selamat Anda dinyatakan <?php echo e($siswa->status); ?> pada tahun ajaran 2020/2021 </h1>
          <?php else: ?>

          <?php endif; ?>
          </div>
          <!-- Content Row -->
          <div class="row">
          <table class="table m-3">
                            <tbody>
                            
                            <tr>
                                    <td class="bg-success text-white">Data Siswa </td>
                                    <td class="bg-success"></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Nama: </td>
                                    <td><?php echo e($siswa->name); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">NISN: </td>
                                    <td><?php echo e($siswa->nisn); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">NIS: </td>
                                    <td><?php echo e($siswa->nis); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">NO SKL: </td>
                                    <td><?php echo e($siswa->noskl); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Tempat Lahir: </td>
                                    <td><?php echo e($siswa->tmp_lahir); ?></td>
                                </tr>
                                <tr>
                                    <td class="bg-success text-white">Tanggal Lahir: </td>
                                    <td><?php echo e($siswa->tgl_lahir); ?></td>
                                </tr>
                                
                                <tr>
                                    <td class="bg-success text-white">Status: </td>
                                    <td><?php echo e($siswa->status); ?></td>
                                </tr>
                            </tbody>
                        </table>

                  <a href="/" class="btn btn-sm btn-primary btn-block">Kembali ke home</a> 
          </div>
        
         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.siswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\darulkholidin\resources\views/infodetaillulus.blade.php ENDPATH**/ ?>