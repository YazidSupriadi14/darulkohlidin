<?php $__env->startSection('content'); ?>
  
  <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Daftar User </h1>
          </div>

          <!-- Content Row -->
          <div class="row">
            <div class="card-body text-gray-800">
              
              <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">No</th>
      <th scope="col">Username</th>
      <th scope="col">Email</th>
      <th scope="col">Role</th>
      <th scope="col">change status</th>
    
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php $i = 1 ?>
  <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <th scope="row"><?php echo e($i++); ?></th>
      <td><?php echo e($item->name); ?></td>
      <td><?php echo e($item->email); ?></td>
      
      <td><?php echo e($item->role); ?></td>
      <td><?php if($item->rules == 'asdos'): ?>
            <a href="<?php echo e(url('admin/user/role/'.$item->id)); ?>" class="btn btn-primary btn-sm">Make admin</a>
          <?php else: ?>
            <a href="<?php echo e(url('admin/user/role/'.$item->id)); ?>" class="btn btn-danger btn-sm ">Make other Rules</a>
         <?php endif; ?>
      </td>
      <td>
<?php if(Auth::check() == $item->name ): ?>
    <?php if(Auth::user()->name == $item->name ): ?>

    <?php else: ?>
<form action="<?php echo e(url('admin/user/delete',$item->id)); ?>" method="post" class="d-inline">
  <?php echo csrf_field(); ?>
  <?php echo method_field('delete'); ?>
  <button class="btn btn-sm btn-danger"></i>Delete</button>
</form>
<?php endif; ?>
 <?php else: ?>

 <?php endif; ?>
      </td>
    </tr>
   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td class="text-center" colspan="7">Data Kosong</td>
           </tr> 
    <?php endif; ?>
  </tbody>
</table>


              </div>
            </div>
          </div>
         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\darulkholidin\resources\views/pages/admin/user/index.blade.php ENDPATH**/ ?>