<?php $__env->startSection('content'); ?>
  
  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Tambah Nilai Mata Pelajaran Siswa</h1>
          </div>

          <?php if($errors ->any()): ?>
            <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
          <!-- Content Row -->
          <div class="card-shadow">
            <div class="card-body">
              <form action="<?php echo e(url('/sma/siswa/detail/mapeladd/store',$siswa->id)); ?>" method="post" >
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Agama</label>
                  <input type="text" class="form-control" name="agama" placeholder="Masukan Nilai Agama" value="<?php echo e(old('agama')); ?>">
                </div>
                <div class="form-group">
                  <label>Pendidikan Kewarganegaraan</label>
                  <input type="text" class="form-control" name="pkn" placeholder="Masukan Nilai PKN" value="<?php echo e(old('pkn')); ?>">
                </div>
                <div class="form-group">
                  <label>Bahasa Indonesia</label>
                  <input type="text" class="form-control" name="bahasa_indonesia" placeholder="Masukan Nilai Bahasa Indonesia" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                  <label>Matematika</label>
                  <input type="text" class="form-control" name="mtk" placeholder="Masukan Nilai Matematika" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                  <label>Sejarah</label>
                  <input type="text" class="form-control" name="sejarah" placeholder="Masukan Nilai Sejarah" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                  <label>Bahasa Inggris</label>
                  <input type="text" class="form-control" name="bahasa_inggris" placeholder="Masukan Nilai Bahasa Inggris" value="<?php echo e(old('name')); ?>">
                </div>
            
                <div class="form-group">
                  <label>Seni Budaya</label>
                  <input type="text" class="form-control" name="seni_budaya" placeholder="Masukan Nilai Seni Budaya" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                  <label>Pendidikan Jasmani Olahraga dan Kesehatan</label>
                  <input type="text" class="form-control" name="pjok" placeholder="Masukan Nilai PJOK" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                  <label>PRKW</label>
                  <input type="text" class="form-control" name="prkw" placeholder="Masukan Nilai PRKW" value="<?php echo e(old('name')); ?>">
                </div>
                
                <div class="form-group">
                  <label>Bahasa Sunda</label>
                  <input type="text" class="form-control" name="bahasa_sunda" placeholder="Masukan Nilai Bahasa Sunda" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                  <label>Matematika Peminatan</label>
                  <input type="text" class="form-control" name="mtk_peminatan" placeholder="Masukan Nilai Matematika Peminatan" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                  <label>Biologi</label>
                  <input type="text" class="form-control" name="biologi" placeholder="Masukan Nilai Biologi" value="<?php echo e(old('name')); ?>">
                </div>
                
                <div class="form-group">
                  <label>Fisika</label>
                  <input type="text" class="form-control" name="fisika" placeholder="Masukan Nilai Fisika" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                  <label>Kimia</label>
                  <input type="text" class="form-control" name="kimia" placeholder="Masukan Nilai Kimia" value="<?php echo e(old('name')); ?>">
                </div>
                
                <div class="form-group">
                  <label>Bahasa Arab</label>
                  <input type="text" class="form-control" name="bahasa_arab" placeholder="Masukan Nilai Bahasa Arab" value="<?php echo e(old('name')); ?>">
                </div>
                <input type="hidden" class="form-control" name="siswa_id" value="<?php echo e($siswa->id); ?>">
                
                <button type="submit" class="btn btn-primary">Submit</button>
              </form>
            </div>
          </div>
        
         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\darulkholidin\resources\views/pages/admin/sma/mapeladd.blade.php ENDPATH**/ ?>