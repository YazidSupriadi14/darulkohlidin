<?php $__env->startSection('content'); ?>
  
  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Tambah Data Siswa</h1>
          </div>

          <?php if($errors ->any()): ?>
            <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
          <!-- Content Row -->
          <div class="card-shadow">
            <div class="card-body">
              <form action="<?php echo e(url('/sma/siswa/store')); ?>" method="post" >
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Nama Siswa</label>
                  <input type="text" class="form-control" name="name" placeholder="Masukan Nama Siswa" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                  <label>NISN</label>
                  <input type="text" class="form-control" name="nisn" placeholder="Masukan Nomor NISN" value="<?php echo e(old('nisn')); ?>">
                </div>
                <div class="form-group">
                  <label>NIS</label>
                  <input type="text" class="form-control" name="nis" placeholder="Masukan Nomor NIS" value="<?php echo e(old('nis')); ?>">
                </div>
                
                <div class="form-group">
                  <label>NO SKL</label>
                  <input type="text" class="form-control" name="noskl" placeholder="Masukan Nomor SKL Siswa" value="<?php echo e(old('noskl')); ?>">
                </div>
                
                <div class="form-group">
                  <label>Tempat Lahir</label>
                  <input type="text" class="form-control" name="tmp_lahir" placeholder="Masukan Tempat Lahir Siswa" value="<?php echo e(old('tmp_lahir')); ?>">
                </div>
                
                <div class="form-group">
                  <label>Tanggal Lahir</label>
                  <input type="date" class="form-control" name="tgl_lahir" >
                </div>

                <div class="form-group">
                     
                        <label for="slug">Status Kelulusan</label>
                          <select name="status" class="form-control">
                        
                          
                          <option value="">Pilih Status Kelulusan</option>
                              
                              <option value="lulus">Lulus</option>
                              <option value="tidak lulus">Tidak Lulus</option>

                          </select>
                      
                      </div>
              
                <button type="submit" class="btn btn-primary">Submit</button>
              </form>
            </div>
          </div>
        
         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\darulkholidin\resources\views/pages/admin/sma/add.blade.php ENDPATH**/ ?>