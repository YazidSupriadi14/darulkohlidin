<?php $__env->startSection('content'); ?>
  
  <!-- Page Heading -->
          <div class=" jumbotron bg-success text-light">
           <h1 class=" text-center">Info Kelulusan SMA Darul Kholidin </h1>
          </div>
          <!-- Content Row -->
          <div class="row">

          <table class="table mt-3">
  <thead class="thead-dark">
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama</th>
      <th scope="col">Nisn</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php $i = 1 ?>
  <?php $__empty_1 = true; $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <th scope="row"><?php echo e($i++); ?></th>
      <td><?php echo e($item->name); ?></td>
      <td><?php echo e($item->nisn); ?></td>
      
      <td>
      
      <a href="<?php echo e(url('sma/detaillulus',$item->id)); ?>"  class="btn btn-sm btn-info" title="">View</a>
      
      </td>
    </tr>
   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td class="text-center" colspan="7">Siswa Tidak Ditemukan</td>
           </tr> 
    <?php endif; ?>
  </tbody>
</table>
            
          </div>
        
         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.siswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\darulkholidin\resources\views/infolulus.blade.php ENDPATH**/ ?>