	<!-- navbar -->
<div class="container">
	<nav class=" rownavbar navbar-expand-lg navbar-light bg-light ">
		<div class="navbar-nav mr-auto ml-auto mr-sm-auto mr-lg-0 mr-md-auto">
			
			<a href="" title="" class="navbar-brand">
				
			</a>

		</div>

		<ul class="navbar-nav mr-auto ml-auto d-none d-lg-block">
		
			<li>	<img src="{{url('frontend/images/logo.png')}}" height="60px" alt="">
<span class="text-muted"> | &nbsp; Beyound and explore the world </span></li>
		</ul>
	</nav>
</div>
