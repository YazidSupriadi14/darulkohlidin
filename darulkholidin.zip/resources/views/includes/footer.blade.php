
	<footer class="section-footer mt-5 pb-4 border-top">
		<div class="container pt-5 pb-5">
				<div class="row justify-content-center">
					<div class="col-12">
					 	<div class="row">
					 		<div class="col-12 col-lg-3">
					 			<h5>Features</h5>
					 			<ul class="list-unstyled">
					 				<li><a href="#" title="">Reviews</a></li>
					 					<li><a href="#" title="">Content</a></li>
					 					<li><a href="#" title="">Comunity</a></li>	
					 					<li><a href="#" title="">affiliate</a></li>
					 			</ul>
					 		</div>
					 		<div class="col-12 col-lg-3">
					 			<h5>Accounts</h5>
					 			<ul class="list-unstyled">
					 				<li><a href="#" title="">Security</a></li>
					 					<li><a href="#" title="">Profile</a></li>
					 					<li><a href="#" title="">Reward</a></li>	
					 			</ul>
					 		</div>
					 		<div class="col-12 col-lg-3">
					 			<h5>Social Media</h5>
					 			<ul class="list-unstyled">
					 				<li><a href="#" title="">Twitter</a></li>
					 					<li><a href="#" title="">Facebook</a></li>
					 					<li><a href="#" title="">Instagram</a></li>	
					 					<li><a href="#" title="">Google</a></li>
					 			</ul>
					 		</div>
					 		<div class="col-12 col-lg-3">
					 			<h5>Get Connected</h5>
					 			<ul class="list-unstyled">
					 				<li><a href="#" title="">Jakarta Selatan</a></li>
					 					<li><a href="#" title="">Indonesia</a></li>
					 					<li><a href="#" title="">081907284634</a></li>	
					 					<li><a href="#" title="">TravelJauh@gmail.com</a></li>
					 			</ul>
					 		</div>
					 	</div>
					 </div> 
				</div>

		</div>
		<div class="container-fluid">
				<div class="border-top row justify-content-center align-items-center-center pt-4">
					<div class="col-auto font-weight-light text-gray-dark">
						Copyright2019.
					</div>
				</div>
		</div>	
	</footer>

