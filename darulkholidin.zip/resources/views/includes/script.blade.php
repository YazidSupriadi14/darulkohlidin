
	<script src="{{url('frontend/libraries/jquery/jquery-3.4.1.min.js')}}" type="text/javascript" charset="utf-8" async defer></script>
	<script src="{{url('frontend/libraries/bootstrap/js/bootstrap.js')}}" type="text/javascript" charset="utf-8" async defer></script>
	<script src="{{url('/frontend/libraries/retina/retina.min.js')}}" type="text/javascript" charset="utf-8" async defer></script>
	<script src="{{url('/frontend/libraries/dist/xzoom.min.js')}}" type="text/javascript" charset="utf-8" async defer></script>