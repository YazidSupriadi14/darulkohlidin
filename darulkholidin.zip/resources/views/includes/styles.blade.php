
	<link rel="stylesheet" type="text/css" href="{{url('frontend/libraries/bootstrap/css/bootstrap.css')}}">
	<link rel="stylesheet" type="text/css" href="{{url('frontend/libraries/dist/xzoom.css')}}">

	<link rel="stylesheet" type="text/css" href="{{url('frontend/styles/mains.css')}}">
	<link href="https://fonts.googleapis.com/css?family=Assistant:400,600,700,800|Playfair+Display:400,700,700i,900,900i&display=swap" rel="stylesheet">